<?php

class empresa {

    private $idEmpresa;
    private $nombre;
    private $rfc;
    private $giro;
    private $direccion;
    private $telefono;

    function __construct($idEmpresa, $nombre, $rfc, $giro, $direccion, $telefono) {
        $this->idEmpresa = $idEmpresa;
        $this->nombre = $nombre;
        $this->rfc = $rfc;
        $this->giro = $giro;
        $this->direccion = $direccion;
        $this->telefono = $telefono;
    }
    function getIdEmpresa() {
        return $this->idEmpresa;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getRfc() {
        return $this->rfc;
    }

    function getGiro() {
        return $this->giro;
    }

    function getDireccion() {
        return $this->direccion;
    }

    function getTelefono() {
        return $this->telefono;
    }

    function setIdEmpresa($idEmpresa) {
        $this->idEmpresa = $idEmpresa;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setRfc($rfc) {
        $this->rfc = $rfc;
    }

    function setGiro($giro) {
        $this->giro = $giro;
    }

    function setDireccion($direccion) {
        $this->direccion = $direccion;
    }

    function setTelefono($telefono) {
        $this->telefono = $telefono;
    }


}
