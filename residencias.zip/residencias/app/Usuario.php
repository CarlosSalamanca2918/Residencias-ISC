<?php

class Usuario{
    private $id;
    private $nombre;
    private $sexo;
    private $telefono;
    private $email;
    
    public function _construct($id,$nombre,$sexo,$telefono,$email){
        $this -> id=$id;
        $this -> nombre=$nombre;
        $this -> sexo=$sexo;
        $this -> telefono=$telefono;
        $this -> email=$email;
    }
    function getId() {
        return $this->id;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getSexo() {
        return $this->sexo;
    }

    function getTelefono() {
        return $this->telefono;
    }

    function getEmail() {
        return $this->email;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setSexo($sexo) {
        $this->sexo = $sexo;
    }

    function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    function setEmail($email) {
        $this->email = $email;
    }

 
}
