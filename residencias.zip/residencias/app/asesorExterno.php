<?php

class asesorExterno {

    private $idAsesorExterno;
    private $nombre;
    private $email;
    private $telefono;
    private $puesto;

    function __construct($idAsesorExterno, $nombre, $email, $telefono, $puesto) {
        $this->idAsesorExterno = $idAsesorExterno;
        $this->nombre = $nombre;
        $this->email = $email;
        $this->telefono = $telefono;
        $this->puesto = $puesto;
    }
    function getIdAsesorExterno() {
        return $this->idAsesorExterno;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getEmail() {
        return $this->email;
    }

    function getTelefono() {
        return $this->telefono;
    }

    function getPuesto() {
        return $this->puesto;
    }

    function setIdAsesorExterno($idAsesorExterno) {
        $this->idAsesorExterno = $idAsesorExterno;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setEmail($email) {
        $this->email = $email;
    }

    function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    function setPuesto($puesto) {
        $this->puesto = $puesto;
    }



}
