<?php

class reporteParcial {

    private $idReporteParcial;
    private $nombre;
    private $noReporte;
    private $fechaEvaluacion;

    function __construct($idReporteParcial, $nombre, $noReporte, $fechaEvaluacion) {
        $this->idReporteParcial = $idReporteParcial;
        $this->nombre = $nombre;
        $this->noReporte = $noReporte;
        $this->fechaEvaluacion = $fechaEvaluacion;
    }

    function getIdReporteParcial() {
        return $this->idReporteParcial;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getNoReporte() {
        return $this->noReporte;
    }

    function getFechaEvaluacion() {
        return $this->fechaEvaluacion;
    }

    function setIdReporteParcial($idReporteParcial) {
        $this->idReporteParcial = $idReporteParcial;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setNoReporte($noReporte) {
        $this->noReporte = $noReporte;
    }

    function setFechaEvaluacion($fechaEvaluacion) {
        $this->fechaEvaluacion = $fechaEvaluacion;
    }

}
