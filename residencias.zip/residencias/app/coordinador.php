<?php

class coordinador {

    private $idCoordinador;
    private $nombreCarrera;
    private $Tcreditos;
    private $nombreCoordinador;

    function __construct($idCoordinador, $nombreCarrera, $Tcreditos, $nombreCoordinador) {
        $this->idCoordinador = $idCoordinador;
        $this->nombreCarrera = $nombreCarrera;
        $this->Tcreditos = $Tcreditos;
        $this->nombreCoordinador = $nombreCoordinador;
    }

}

function getIdCoordinador() {
    return $this->idCoordinador;
}

 function getNombreCarrera() {
    return $this->nombreCarrera;
}

 function getTcreditos() {
    return $this->Tcreditos;
}

 function getNombreCoordinador() {
    return $this->nombreCoordinador;
}

 function setIdCoordinador($idCoordinador) {
    $this->idCoordinador = $idCoordinador;
}

 function setNombreCarrera($nombreCarrera) {
    $this->nombreCarrera = $nombreCarrera;
}

 function setTcreditos($Tcreditos) {
    $this->Tcreditos = $Tcreditos;
}

 function setNombreCoordinador($nombreCoordinador) {
    $this->nombreCoordinador = $nombreCoordinador;
}


