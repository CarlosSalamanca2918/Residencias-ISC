<?php

class proyectos {

    private $idProyectos;
    private $titulo;
    private $estatus;
    private $fechaRegistro;
    private $fechaAceptacion;
    private $Contenido;
    private $Periodo;
    private $Calificacion;

    function __construct($idProyectos, $titulo, $estatus, $fechaRegistro, $fechaAceptacion, $Contenido, $Periodo, $Calificacion) {
        $this->idProyectos = $idProyectos;
        $this->titulo = $titulo;
        $this->estatus = $estatus;
        $this->fechaRegistro = $fechaRegistro;
        $this->fechaAceptacion = $fechaAceptacion;
        $this->Contenido = $Contenido;
        $this->Periodo = $Periodo;
        $this->Calificacion = $Calificacion;
    }
    function getIdProyectos() {
        return $this->idProyectos;
    }

    function getTitulo() {
        return $this->titulo;
    }

    function getEstatus() {
        return $this->estatus;
    }

    function getFechaRegistro() {
        return $this->fechaRegistro;
    }

    function getFechaAceptacion() {
        return $this->fechaAceptacion;
    }

    function getContenido() {
        return $this->Contenido;
    }

    function getPeriodo() {
        return $this->Periodo;
    }

    function getCalificacion() {
        return $this->Calificacion;
    }

    function setIdProyectos($idProyectos) {
        $this->idProyectos = $idProyectos;
    }

    function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    function setEstatus($estatus) {
        $this->estatus = $estatus;
    }

    function setFechaRegistro($fechaRegistro) {
        $this->fechaRegistro = $fechaRegistro;
    }

    function setFechaAceptacion($fechaAceptacion) {
        $this->fechaAceptacion = $fechaAceptacion;
    }

    function setContenido($Contenido) {
        $this->Contenido = $Contenido;
    }

    function setPeriodo($Periodo) {
        $this->Periodo = $Periodo;
    }

    function setCalificacion($Calificacion) {
        $this->Calificacion = $Calificacion;
    }


}
