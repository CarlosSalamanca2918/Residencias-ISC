<?php

class reportesEvaluacion {

    private $idReportesEvaluacion;
    private $CalificacionInterno;
    private $CalificacionExterno;
    private $promedio;
    private $fechaEvaluacion;
    private $evidencia;

    function __construct($idReportesEvaluacion, $CalificacionInterno, $CalificacionExterno, $promedio, $fechaEvaluacion, $evidencia) {
        $this->idReportesEvaluacion = $idReportesEvaluacion;
        $this->CalificacionInterno = $CalificacionInterno;
        $this->CalificacionExterno = $CalificacionExterno;
        $this->promedio = $promedio;
        $this->fechaEvaluacion = $fechaEvaluacion;
        $this->evidencia = $evidencia;
    }
    function getIdReportesEvaluacion() {
        return $this->idReportesEvaluacion;
    }

    function getCalificacionInterno() {
        return $this->CalificacionInterno;
    }

    function getCalificacionExterno() {
        return $this->CalificacionExterno;
    }

    function getPromedio() {
        return $this->promedio;
    }

    function getFechaEvaluacion() {
        return $this->fechaEvaluacion;
    }

    function getEvidencia() {
        return $this->evidencia;
    }

    function setIdReportesEvaluacion($idReportesEvaluacion) {
        $this->idReportesEvaluacion = $idReportesEvaluacion;
    }

    function setCalificacionInterno($CalificacionInterno) {
        $this->CalificacionInterno = $CalificacionInterno;
    }

    function setCalificacionExterno($CalificacionExterno) {
        $this->CalificacionExterno = $CalificacionExterno;
    }

    function setPromedio($promedio) {
        $this->promedio = $promedio;
    }

    function setFechaEvaluacion($fechaEvaluacion) {
        $this->fechaEvaluacion = $fechaEvaluacion;
    }

    function setEvidencia($evidencia) {
        $this->evidencia = $evidencia;
    }


}
