<?php

class docentes {

    private $noDocente;
    private $escolaridad;
    private $carreraAdscrito;
    private $cantidadProyectos;

    function __construct($noDocente, $escolaridad, $carreraAdscrito, $cantidadProyectos) {
        $this->noDocente = $noDocente;
        $this->escolaridad = $escolaridad;
        $this->carreraAdscrito = $carreraAdscrito;
        $this->cantidadProyectos = $cantidadProyectos;
    }
    function getNoDocente() {
        return $this->noDocente;
    }

    function getEscolaridad() {
        return $this->escolaridad;
    }

    function getCarreraAdscrito() {
        return $this->carreraAdscrito;
    }

    function getCantidadProyectos() {
        return $this->cantidadProyectos;
    }

    function setNoDocente($noDocente) {
        $this->noDocente = $noDocente;
    }

    function setEscolaridad($escolaridad) {
        $this->escolaridad = $escolaridad;
    }

    function setCarreraAdscrito($carreraAdscrito) {
        $this->carreraAdscrito = $carreraAdscrito;
    }

    function setCantidadProyectos($cantidadProyectos) {
        $this->cantidadProyectos = $cantidadProyectos;
    }


}
