<?php

class alumno {

    private $noControl;
    private $semestre;
    private $promedio;
    private $creditos;
    private $nombreCarrera;

    function __construct($noControl, $semestre, $promedio, $creditos, $nombreCarrera) {
        $this->noControl = $noControl;
        $this->semestre = $semestre;
        $this->promedio = $promedio;
        $this->creditos = $creditos;
        $this->nombreCarrera = $nombreCarrera;
    }
    function getNoControl() {
        return $this->noControl;
    }

    function getSemestre() {
        return $this->semestre;
    }

    function getPromedio() {
        return $this->promedio;
    }

    function getCreditos() {
        return $this->creditos;
    }

    function getNombreCarrera() {
        return $this->nombreCarrera;
    }

    function setNoControl($noControl) {
        $this->noControl = $noControl;
    }

    function setSemestre($semestre) {
        $this->semestre = $semestre;
    }

    function setPromedio($promedio) {
        $this->promedio = $promedio;
    }

    function setCreditos($creditos) {
        $this->creditos = $creditos;
    }

    function setNombreCarrera($nombreCarrera) {
        $this->nombreCarrera = $nombreCarrera;
    }


}
