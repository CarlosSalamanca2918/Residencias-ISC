<?php

class periodosRegistro {

    private $idPeriodo;
    private $nombre;
    private $fechaInicio;
    private $fechaFin;

    function __construct($idPeriodo, $nombre, $fechaInicio, $fechaFin) {
        $this->idPeriodo = $idPeriodo;
        $this->nombre = $nombre;
        $this->fechaInicio = $fechaInicio;
        $this->fechaFin = $fechaFin;
    }
    function getIdPeriodo() {
        return $this->idPeriodo;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getFechaInicio() {
        return $this->fechaInicio;
    }

    function getFechaFin() {
        return $this->fechaFin;
    }

    function setIdPeriodo($idPeriodo) {
        $this->idPeriodo = $idPeriodo;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setFechaInicio($fechaInicio) {
        $this->fechaInicio = $fechaInicio;
    }

    function setFechaFin($fechaFin) {
        $this->fechaFin = $fechaFin;
    }


}
