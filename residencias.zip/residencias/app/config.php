
<?php

$nombre_servidor='localhost';
$nombre_usuario='root';
$password='';
$nombre_base_datos='residencias';