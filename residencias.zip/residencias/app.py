from flask import Flask,render_template,request,abort,redirect,url_for
from flask_login import LoginManager, current_user, login_user, logout_user, login_required

from modelo.models import db, Opcion
from modelo.models import Alumnos,ReporteParcial, Usuario, ReportesEvaluacion, Coordinador, Docentes, Proyectos, AsesorExterno, Empresa
import json
from flask_sqlalchemy import SQLAlchemy
import pymysql

#db = pymysql.connect('localhost','root','','Residencias')
#print (db)

app=Flask(__name__)
app.secret_key='Residencias'
#db=SQLAlchemy(app)
app.config['SQLALCHEMY_DATABASE_URI']='mysql+pymysql://Salamanca:KING1829@localhost/Residencias'
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
#Configuración de la gestion Usuarios con Flask-Login
login_manager=LoginManager()
login_manager.init_app(app)
login_manager.login_view="inicio"
#rutas para el ingreso a la aplicacion

@login_manager.user_loader
def load_user(id):
    return Usuario.query.get(int(id))
@app.route('/')
def inicio():
    #return 'Bienvenido a FLASK'
    if current_user.is_authenticated:
        return render_template('principal.html')
    else:
        return render_template('login.html')

@app.route('/login',methods=['POST'])
def login():
    #return 'Procesando las credenciales.'
    u=Usuario()
    usuario=u.validar(request.form['email'],request.form['password'])
    if usuario!=None:
        login_user(usuario)
        return render_template('principal.html')
    else:
        return 'Usuario invalido'

@app.route('/cerrarSesion')
@login_required
def cerrarSesion():
    if current_user.is_authenticated:
        logout_user()
    else:
        abort(404)
    return redirect(url_for("inicio"))
#fin de las rutas del acceso al sistema
@app.route('/registrarUsuario')
def registrarUsuario():
    return render_template('Usuarios/altaUsuarios.html')
@app.route('/guardarUsuario',methods=['post'])
def guardarUsuario():
    usuario=Usuario()
    usuario.nombre=request.form['nombre']
    usuario.sexo = request.form['sexo']
    usuario.telefono = request.form['telefono']
    usuario.email = request.form['email']
    usuario.estatus = request.form['estatus']
    usuario.tipo = request.form['tipoUsuario']
    usuario.password=request.form['password']
    usuario.insertar()
    return render_template('index.html')
@app.route('/registrarProducto')
def regsitrarProducto():
    return 'registrando un producto'

@app.route('/eliminarDocente/<int:noDocente>')
@login_required
def eliminarDocente(noDocente):
    return 'Eliminando al Docente:'+str(noDocente)
@app.route('/consultarDocente/<id>')
@login_required
def consultarDocente(id):
    return 'consultando los datos del docente:'+id
#Inicio del CRUD de alumnos
@app.route('/alumnos/new')
@login_required
def nuevoAlumno():
    return render_template('Alumnos/altaAlumno.html')

@app.route('/alumnos/save',methods=['POST'])
@login_required
def guardar_alumno():
    try:
        nombre=request.form['nombre']
    except:
        abort(500)
    return nombre
@app.route('/alumnos/edit')
@login_required
def editarAlumno():
    return render_template('Alumnos/editarAlumno.html')

@app.route('/alumnos/delete')
@login_required
def eliminarAlumno():
    return render_template('Alumnos/eliminarAlumno.html')

@app.route('/alumnos')
def consultarAlumnos():
    return render_template('Alumnos/consultaAlumno.html')
#fin del CRUD alumnos

#CRUD Coordinador
@app.route('/Coordinador/new')
@login_required
def nuevoCoordinador():
    return render_template('Coordinador/altaCoordinador.html')

@app.route('/Coordinador/altaCoordinador',methods=['POST'])
@login_required
def agregarCoordinador():
    try:
        e=Coordinador()
        e.nombreCarrera=request.form['nombreCarrera']
        e.Tcreditos=request.form['Tcreditos']
        e.nombreCoordinador=request['nombreCoordinador']
        e.insertar()
        return redirect(url_for('consultaCoordinador'))
    except:
        abort(500)
@app.route('/Coordinador')
def consultarCoordinador():
    e=Coordinador()
    coordinador=e.consultaGeneral()
    return render_template('Coordinador/consultaCoordinador.html', coordinador=coordinador)

@app.route('/coordinador/editarCoordinador/<int:id>')
@login_required
def editarCoordinador(id):
    e=Coordinador()
    e.idCoordinador=id
    coordinador=e.consultaIndividual()
    return render_template('Coordinador/editarCoordinador.html', coordinador=coordinador)
@app.route('/coordinador/modificar', methods=['POST'])
@login_required
def modificarCoordinador():
    e=Coordinador()
    e.idCoordinador=request.form['id']
    e.nombreCarrera=request.form['nombreCarrera']
    e.Tcreditos=request.form['Tcreditos']
    e.nombreCoordinador=request.form['nombreCoordinador']
    e.actualizar()
    return redirect(url_for("consultarCoordinador"))
@app.route('/coordinador/delete/<int:id>')
@login_required
def eliminarCoordinador(id):
    e=Coordinador()
    e.idCoordinador=id
    e.eliminar()
    return redirect(url_for("consultarCoordinador"))
#Fin CRUD
#crud de Docentes
@app.route('/docentes')
def consultarDocentes():
    d=Docentes()
    docentes=d.consultaGeneral()
    return render_template('Docentes/ConsultaDocentes.html',docentes=docentes)
@app.route('/docentes/new')
@login_required
def nuevoDocente():
    d = Docentes()
    return render_template('Docentes/altaDocentes.html',docentes=d.consultaGeneral())
@app.route('/docentes/save',methods=['POST'])
@login_required
def guardarDocente():
    d=Docentes()
    d.Escolaridad=request.form['Escolaridad']
    d.carreraAdscrito=request.form['carreraAdscrito']
    d.cantidadProyectos=request.form['cantidadProyectos']
    d.insertar()
    return redirect(url_for('consultarDocentes'))
#fin crud docentes

#CRUD Opciones (Ajax)
@app.route("/proyectos")
def opciones():
    return render_template('Proyectos/altaProyectos.html')

@app.route('/proyectos/consultaGeneral')
def consultarProyectos():
    proyectos=Proyectos()
    lista=[]
    for p in proyectos.consultaGeneral():
        lista.append({"idProyectos":p.idProyectos,"titulo":p.titulo,"estatus":p.estatus,"fechaRegistro":p.fechaRegistro,"fechaAceptacion":p.fechaAceptacion,"contenido":p.Contenido,"periodo":p.Contenido,"calificacion":p.calificacion})
    return json.dumps(lista)
@app.route('/proyectos/guardar/<data>',methods=['get'])
def guaradarProyectos(data):
    proyectos=Proyectos()
    datos=json.loads(data)
    proyectos.titulo=datos['titulo']
    proyectos.estatus=datos['estatus']
    proyectos.fechaRegistro=datos['fechaRegistro']
    proyectos.fechaAceptacion=datos['fechaAceptacion']
    proyectos.contenido=datos['contenido']
    proyectos.periodo=datos['periodo']
    proyectos.calificacion=datos['calificacion']
    proyectos.insertar()
    return 'Proyectos agregada con exito'
@app.route('/Proyectos')
def consultarProyectos(id):
    proyectos=Proyectos()
    proyectos.idProyectos=id
    proyectos=proyectos.consultaIndividual()
    dicProyectos={"idProyectos":proyectos.idProyectos,"titulo":proyectos.titulo,"estatus":proyectos.estatus,"fechaRegistro":proyectos.fechaRegistro,"fechaAceptacion":proyectos.fechaAceptacion,"contenido":proyectos.contenido,"periodo":proyectos.periodo,"calificacion":proyectos.calificacion}
    return json.dumps(id)
@app.route('/Proyectos/editarProyectos/<data>',methods=['get'])
def modifcarProyectos(data):
    proyectos = Proyectos()
    datos = json.loads(data)
    proyectos.idProyectos=datos['idProyectos']
    proyectos.titulo = datos['titulo']
    proyectos.estatus = datos['estatus']
    proyectos.fechaRegistro=datos['fechaRegistro']
    proyectos.fechaAceptacion=datos['fechaAceptacion']
    proyectos.Contenido=datos['Contenido']
    proyectos.periodo=datos['Periodo']
    proyectos.calificacion=datos['Calificacion']
    Opcion.actualizar()
    return 'Proyecto modificada con exito'
@app.route('/proyectos/eliminarProyecto/<int:id>')
def eliminarProyecto(id):
    proyectos = Proyectos()
    proyectos.idProyectos=id
    proyectos.eliminar()
    return 'proyectos eliminada con exito'


@app.errorhandler(404)
def error_404(e):
    return render_template('comunes/error_404.html'),404

@app.errorhandler(500)
def error_500(e):
    return render_template('comunes/error_500.html'),500

if __name__=='__main__':
    db.init_app(app)
    app.run(debug=True)

