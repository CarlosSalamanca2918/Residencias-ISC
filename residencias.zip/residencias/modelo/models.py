from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Integer,String,Column,ForeignKey,DATETIME
from sqlalchemy.orm import relationship
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

db=SQLAlchemy()

class Usuario(UserMixin,db.Model):
    __tablename__='Usuarios'
    idUsuario=Column(Integer,primary_key=True)
    nombre=Column(String,nullable=False)
    sexo=Column(String,nullable=False)
    telefono=Column(String,nullable=False)
    email = Column(String, nullable=False)
    estatus = Column(String, nullable=False)
    tipoUsuario = Column(String, nullable=False)
    password_hash = Column(String(128), nullable=False)
    #Métodos para el cifrado de la contraseña
    @property
    def password(self):
        raise AttributeError('El atributo password no es un atributo de lectura')
    @password.setter
    def password(self,password):
        self.password_hash=generate_password_hash(password)
    def validarPassword(self,password):
        return check_password_hash(self.password_hash,password)
    #metodos del CRUD
    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def consultaIndividual(self):
        return self.query.get(self.idUsuario)
        Usuario=relationship('Usuarios',backref='Docentes',lazy='dynamic')
        Usuario=relationship('Usuarios',backref='Coordinador',lazy='dynamic')
        Usuario=relationship('Usuarios',backref='Alumnos',lazy='dynamic')

    #Metodos para el perfilamiento de los usuarios
    def is_authenticated(self):
        return True
    def is_anonymous(self):
        return False
    def is_active(self):
        if self.estatus=='A':
            return True
        else:
            return False
    def is_admin(self):
        if self.tipoUsuario=='A':
            return True
        else:
            return False
    def getTipo(self):
        return self.tipoUsuario
    def get_id(self):
        return self.idUsuario
    def validar(self,email,password):
        user=Usuario.query.filter_by(email=email,estatus='A').first()
        if user!=None:
            if user.validarPassword(password):
                return user
            else:
                return None
        else:
            return None

class Alumnos(db.Model):

    __tablename__='Alumnos'
    noControl=Column(Integer,primary_key=True)
    semestre=Column(Integer,nullable=False)
    promedio=Column(Integer,nullable=False)
    creditos=Column(Integer, nullable=False)
    nombre=Column(String, nullable=False)
    idUsuario=Column(Integer,ForeignKey('Usuarios.idUsuario'))

    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaIndividual(self):
        return self.query.get(self.noControl)

class Coordinador(db.Model):

    __tablename__='Coordinador'
    idCoordinador=Column(Integer,primary_key=True)
    nombreCarrera=Column(String,nullable=False)
    Tcreditos=Column(Integer,nullable=False)
    nombreCoordinador=Column(String, nullable=False)
    idUsuario=Column(Integer,ForeignKey('Usuarios.idUsuario'))

    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaIndividual(self):
        return self.query.get(self.id_Coordinador)

class Docentes(db.Model):

    __tablename__='Docentes'
    noDocente=Column(Integer,primary_key=True)
    Escolaridad=Column(String,nullable=False)
    carreraAdscrito=Column(String,nullable=False)
    cantidadProyectos=Column(Integer, nullable=False)
    idUsuario=Column(Integer,ForeignKey('Usuarios.idUsuario'))
    
    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaIndividual(self):
        return self.query.get(self.noDocente)
        Proyectos=relationship('Proyectos',backref='Docentes',lazy='dynamic')


class Proyectos(db.Model):

    __tablename__='Proyectos'
    idProyectos=Column(Integer,primary_key=True)
    titulo=Column(String,nullable=False)
    estatus=Column(String,nullable=False)
    fechaRegistro=Column(DATETIME, nullable=False)
    fechaAceptacion=Column(DATETIME, nullable=False)
    contenido=Column(String, nullable=False)
    periodo=Column(String, nullable=False)
    calificacion=Column(Integer, nullable=False)
    noDocente=Column(Integer,ForeignKey('Docentes.noDocente'))
    idPeriodo=Column(Integer,ForeignKey('PeriodosRegistro.idPeriodo'))
    idAsesorExterno=Column(Integer,ForeignKey('AsesorExterno.idAsesorExterno'))
    idEmpresa=Column(Integer,ForeignKey('Empresa.idEmpresa'))

    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaIndividual(self):
        return self.query.get(self.idProyectos)

class Empresa(db.Model):

    __tablename__='Empresa'
    idEmpresa=Column(Integer,primary_key=True)
    nombre=Column(String,nullable=False)
    RFC=Column(String,nullable=False)
    giro=Column(String, nullable=False)
    direccion=Column(String, nullable=False)
    telefono=Column(Integer, nullable=False)

    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaIndividual(self):
        Proyectos=relationship('Proyectos',backref='Empresa',lazy='dynamic')
        return self.query.get(self.id_Empresa)

class AsesorExterno(db.Model):

    __tablename__='AsesorExterno'
    idAsesorExterno=Column(Integer,primary_key=True)
    nombre=Column(String,nullable=False)
    email=Column(String,nullable=False)
    Telefono=Column(Integer, nullable=False)
    puesto=Column(String, nullable=False)
    idEmpresa=Column(Integer,ForeignKey('Empresa.idEmpresa'))

    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaIndividual(self):
        Proyectos=relationship('Proyectos',backref='AsesorExterno',lazy='dynamic')
        return self.query.get(self.id_AsesorExterno)

class PeriodosRegistro(db.Model):

    __tablename__='PeriodosRegistro'
    idPeriodo=Column(Integer,primary_key=True)
    nombre=Column(String,nullable=False)
    fechaInicio=Column(DATETIME,nullable=False)
    fechaFin=Column(DATETIME, nullable=False)
    
    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaIndividual(self):
        ReporteParcial=relationship('ReporteParcial',backref='PeriodosRegistro',lazy='dynamic')
        return self.query.get(self.id_Periodo)


class ReportesEvaluacion(db.Model):

    __tablename__='ReportesEvaluacion'
    idReportesEvaluacion=Column(Integer,primary_key=True)
    CalificacionInterno=Column(Integer,nullable=False)
    CalificacionExterno=Column(Integer,nullable=False)
    Promedio=Column(Integer, nullable=False)
    FechaEvaluacion=Column(DATETIME, nullable=False)
    Evidencia=Column(String, nullable=False)
    idReporteParcial=Column(Integer,ForeignKey('reporteParcial.idRporteParcial'))

    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaIndividual(self):
        return self.query.get(self.id_ReportesEvaluacion)

class ReporteParcial(db.Model):

    __tablename__='ReporteParcial'
    idReporteParcial=Column(Integer,primary_key=True)
    nombre=Column(String,nullable=False)
    noReporte=Column(Integer,nullable=False)
    FechaEvaluacion=Column(DATETIME, nullable=False)
    idPeriodo=Column(Integer,ForeignKey('PeriodoRegistro.idPeriodo'))

    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaIndividual(self):
        ReportesEvaluacion=relationship('ReportesEvaluacion',backref='ReporteParcial',lazy='dynamic')
        return self.query.get(self.id_ReporteParcial)

class Opcion(db.Model):

    __tablename__='Opciones'
    idOpcion=Column(Integer,primary_key=True)
    nombre=Column(String,unique=True)
    descripcion=Column(String)

    def insertar(self):
        db.session.add(self)
        db.session.commit()

    def consultaGeneral(self):
        return self.query.all()

    def actualizar(self):
        db.session.merge(self)
        db.session.commit()

    def eliminar(self):
        db.session.delete(self.consultaIndividual())
        db.session.commit()

    def consultaIndividual(self):
        return self.query.get(self.idOpcion)
